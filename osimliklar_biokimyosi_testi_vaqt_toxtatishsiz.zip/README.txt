O‘SIMLIKLAR BIOKIMYOSI TESTI

1. index.html faylini kompyuterda ikki marta bosing — test brauzerda ochiladi.
2. GitHub Pages uchun index.html faylini repository bosh papkasiga yuklang.
3. Settings → Pages → Deploy from a branch → main / root → Save.
4. Hosil bo‘lgan havolani QR-kodga aylantiring.

Test parametrlari:
- 30 ta savol
- 30 daqiqa, vaqtni to‘xtatish imkoniyatisiz
- 2 bo‘lim
- 4 ta javob varianti
- Yakunda ball va foiz
- Telefon va kompyuterga mos dizayn
